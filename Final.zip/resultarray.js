{
    "Results":[
       [
          [
             "Philosophy"
          ],
          [
             "Philosophy"
          ],
          [
             "Computer Science",
             "Math",
             "Philosophy"
          ],
          [
             "Computer Science",
             "Math"
          ],
          [
             "Philosophy",
             "Drama",
             "Music"
          ],
          [
             "HCDE",
             "Informatics"
          ],
          [
             "Philosophy",
             "Foreign Language"
          ],
          [
             "Operations Management"
          ],
          [
             "Philosophy",
             "History"
          ],
          [
             "Philosophy",
             "Biology"
          ],
          [
             "Philosophy",
             "Sociology"
          ],
          [
             "Economics",
             "Psychology",
             "Education"
          ]
       ],
       [
          [
             "Philosophy"
          ],
          [
             "English",
             "Communication"
          ],
          [
             "Philosophy"
          ],
          [
             "Communication",
             "Applied Math"
          ],
          [
             "English",
             "Drama"
          ],
          [
             "Design",
             "HCDE",
             "Informatics"
          ],
          [
             "Foreign Language"
          ],
          [
             "Marketing",
             "Operations Management"
          ],
          [
             "History",
             "English"
          ],
          [
             "Communication",
             "Biology"
          ],
          [
             "Foreign Language",
             "English",
             "Philosophy"
          ],
          [
             "Psychology",
             "Education",
             "Sociology"
          ]
       ],
       [
          [
             "Computer Science",
             "Math",
             "Philosophy"
          ],
          [
             "Philosophy"
          ],
          [
             "Math",
             "Physics",
             "Applied Math"
          ],
          [
             "Computer Science",
             "Math",
             "Applied Math"
          ],
          [
             "Math",
             "Music",
             "Applied Math"
          ],
          [
             "Math",
             "HCDE",
             "Applied Math"
          ],
          [
             "Math",
             "Foreign Language",
             "Statistics"
          ],
          [
             "Operations Management",
             "Applied Math"
          ],
          [
             "Math",
             "History",
             "Statistics"
          ],
          [
             "Math",
             "Biology",
             "Applied Math"
          ],
          [
             "Statistics",
             "International Studies"
          ],
          [
             "Economics",
             "Applied Math"
          ]
       ],
       [
          [
             "Computer Science",
             "Math"
          ],
          [
             "Communication",
             "Applied Math"
          ],
          [
             "Computer Science",
             "Math",
             "Applied Math"
          ],
          [
             "Computer Science",
             "Applied Math",
             "HCDE"
          ],
          [
             "Computer Science",
             "Applied Math",
             "Music"
          ],
          [
             "Informatics",
             "HCDE",
             "Design"
          ],
          [
             "Computer Science",
             "Foreign Language",
             "HCDE"
          ],
          [
             "Informatics",
             "Applied Math",
             "Operations Management"
          ],
          [
             "Computer Science",
             "History",
             "Informatics"
          ],
          [
             "Applied Math",
             "Bioengineering",
             "Physics"
          ],
          [
             "Computer Science",
             "Philosophy",
             "HCDE"
          ],
          [
             "Applied Math",
             "Education",
             "Informatics"
          ]
       ],
       [
          [
             "Philosophy",
             "Drama",
             "Music"
          ],
          [
             "English",
             "Drama"
          ],
          [
             "Math",
             "Music",
             "Applied Math"
          ],
          [
             "Computer Science",
             "Applied Math",
             "Music"
          ],
          [
             "Drama",
             "Music"
          ],
          [
             "Drama",
             "Music",
             "Design"
          ],
          [
             "Foreign Language",
             "Drama",
             "Music"
          ],
          [
             "Drama",
             "Music",
             "Marketing"
          ],
          [
             "Drama",
             "Music",
             "History"
          ],
          [
             "Drama",
             "Music",
             "Biology"
          ],
          [
             "Sociology",
             "Drama",
             "Music"
          ],
          [
             "Education",
             "Drama",
             "Music"
          ]
       ],
       [
          [
             "HCDE",
             "Informatics"
          ],
          [
             "Design",
             "HCDE",
             "Informatics"
          ],
          [
             "Math",
             "HCDE",
             "Applied Math"
          ],
          [
             "Informatics",
             "HCDE",
             "Design"
          ],
          [
             "Drama",
             "Music",
             "Design"
          ],
          [
             "HCDE",
             "Design",
             "Art"
          ],
          [
             "Design",
             "Informatics",
             "English"
          ],
          [
             "Marketing",
             "Art",
             "Informatics"
          ],
          [
             "Informatics",
             "History",
             "Art"
          ],
          [
             "Informatics",
             "Biology",
             "Art"
          ],
          [
             "Informatics",
             "Drama",
             "Art"
          ],
          [
             "Informatics",
             "Education",
             "Art"
          ]
       ],
       [
          [
             "Philosophy",
             "Foreign Language"
          ],
          [
             "Foreign Language"
          ],
          [
             "Math",
             "Foreign Language",
             "Statistics"
          ],
          [
             "Computer Science",
             "Foreign Language",
             "HCDE"
          ],
          [
             "Foreign Language",
             "Drama",
             "Music"
          ],
          [
             "Design",
             "Informatics",
             "English"
          ],
          [
             "Foreign Language",
             "English",
             "Drama"
          ],
          [
             "Foreign Language",
             "English",
             "Marketing"
          ],
          [
             "History",
             "Foreign Language",
             "English"
          ],
          [
             "Foreign Language",
             "Biology",
             "English"
          ],
          [
             "Music",
             "Drama",
             "Foreign Language"
          ],
          [
             "Sociology",
             "Foreign Language",
             "Education"
          ]
       ],
       [
          [
             "Operations Management"
          ],
          [
             "Marketing",
             "Operations Management"
          ],
          [
             "Operations Management",
             "Applied Math"
          ],
          [
             "Informatics",
             "Applied Math",
             "Operations Management"
          ],
          [
             "Drama",
             "Music",
             "Marketing"
          ],
          [
             "Marketing",
             "Art",
             "Informatics"
          ],
          [
             "Foreign Language",
             "English",
             "Marketing"
          ],
          [
             "Marketing",
             "Finance",
             "Accounting"
          ],
          [
             "Marketing",
             "Economics",
             "History"
          ],
          [
             "Finance",
             "Biology",
             "Physics"
          ],
          [
             "Marketing",
             "International Studies",
             "Foreign Language"
          ],
          [
             "Marketing",
             "Education",
             "Economics"
          ]
       ],
       [
          [
             "Philosophy",
             "History"
          ],
          [
             "History",
             "English"
          ],
          [
             "Math",
             "History",
             "Statistics"
          ],
          [
             "Computer Science",
             "History",
             "Informatics"
          ],
          [
             "Drama",
             "Music",
             "History"
          ],
          [
             "Informatics",
             "History",
             "Art"
          ],
          [
             "History",
             "Foreign Language",
             "English"
          ],
          [
             "Marketing",
             "Economics",
             "History"
          ],
          [
             "History"
          ],
          [
             "History",
             "Biology"
          ],
          [
             "International Studies",
             "History"
          ],
          [
             "Sociology",
             "History",
             "Economics"
          ]
       ],
       [
          [
             "Philosophy",
             "Biology"
          ],
          [
             "Communication",
             "Biology"
          ],
          [
             "Math",
             "Biology",
             "Applied Math"
          ],
          [
             "Applied Math",
             "Bioengineering",
             "Physics"
          ],
          [
             "Drama",
             "Music",
             "Biology"
          ],
          [
             "Informatics",
             "Biology",
             "Art"
          ],
          [
             "Foreign Language",
             "Biology",
             "English"
          ],
          [
             "Finance",
             "Biology",
             "Physics"
          ],
          [
             "History",
             "Biology"
          ],
          [
             "Biology",
             "Chemistry",
             "Physics"
          ],
          [
             "Biology",
             "International Studies"
          ],
          [
             "Education",
             "Biology",
             "Physics"
          ]
       ],
       [
          [
             "Philosophy",
             "Sociology"
          ],
          [
             "Foreign Language",
             "English",
             "Philosophy"
          ],
          [
             "Statistics",
             "International Studies"
          ],
          [
             "Computer Science",
             "Philosophy",
             "HCDE"
          ],
          [
             "Sociology",
             "Drama",
             "Music"
          ],
          [
             "Informatics",
             "Drama",
             "Art"
          ],
          [
             "Music",
             "Drama",
             "Foreign Language"
          ],
          [
             "Marketing",
             "International Studies",
             "Foreign Language"
          ],
          [
             "International Studies",
             "History"
          ],
          [
             "Biology",
             "International Studies"
          ],
          [
             "International Studies",
             "Sociology",
             "Foreign Language"
          ],
          [
             "Sociology",
             "International Studies",
             "Economics"
          ]
       ],
       [
          [
             "Economics",
             "Psychology",
             "Education"
          ],
          [
             "Psychology",
             "Education",
             "Sociology"
          ],
          [
             "Economics",
             "Applied Math"
          ],
          [
             "Applied Math",
             "Education",
             "Informatics"
          ],
          [
             "Education",
             "Drama",
             "Music"
          ],
          [
             "Informatics",
             "Education",
             "Art"
          ],
          [
             "Sociology",
             "Foreign Language",
             "Education"
          ],
          [
             "Marketing",
             "Education",
             "Economics"
          ],
          [
             "Sociology",
             "History",
             "Economics"
          ],
          [
             "Education",
             "Biology",
             "Physics"
          ],
          [
             "Sociology",
             "International Studies",
             "Economics"
          ],
          [
             "Psychology",
             "Sociology",
             "Education"
          ]
       ]
    ]
}

