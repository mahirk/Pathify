{
	"Logic": ["logic","There's a reason for everything, and you have always loved to figure it out"],
	"Writing":["writing","Writing outside of class? For some people that sounds crazy, but you have always craved the pen or keyboard"],
	"Math":["math","The rest of your classmates were groaning about their calculus grades; you were looking ahead to the next unit","Applied Math", "Theoretical Math"],
	"Technology":["technology","All those high school late nights spent hacking away or leveling up could be in your future","Human-Centered", "Computer-Centered"],
	"Performance Arts":["performance_arts","The lights. The stage. The art. Be it theater or music, expressing yourself is what you do best"],
	"Design":["design","It could be artsy, it could be functional, but whatever it is you want to create it"],
	"Language":["language","Hello. Hola. Bonjour. Whether its English or one from around the globe, the way we speak speaks to you","English", "Foreign"],
	"Business":["business","That cash money. Whatever you do, you have got to make a profit ","Strategic Side", "Financial Side"],
	"History":["history","Caesar! Elizabeth! Napoleon! Most people have heard of them, but you have always wanted to know more"],
	"Natural Sciences": ["natural_science","You may have a hypothesis about what you want to major in, but you need some further testing to back it up","Biology", "Chemistry", "Physics"],
	"Culture":["culture","Your refined tastes and worldly observations have always put you a step ahead"],
	"Social Sciences":["social_science","Society and relationships; if you are a people person, social science is for you"]
}